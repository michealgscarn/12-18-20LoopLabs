//(c) A+ Computer Science
//www.apluscompsci.com
//Name

import static java.lang.System.*;

public class FactorRunner
{
	public static void main ( String[] args )
	{
		Factor number = new Factor( 5 );
		out.println(number);   //will output "factorial of 5 is 120"

	}
}