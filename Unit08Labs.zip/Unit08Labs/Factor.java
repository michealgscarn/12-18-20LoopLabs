//(c) A+ Computer Science
//www.apluscompsci.com
//Name

import static java.lang.System.*;

public class Factor
{
	private int number;

	public Factor()
	{
	}

	public Factor(int num)
	{
	}

	public void setNum(int num)
	{
	}

	public int getNum()
	{
		return 0;
	}

	public long getFactorial( )
	{
		long factorial=1;







		return factorial;
	}

	public String toString()
	{
		return "factorial of " + getNum() + " is "+ getFactorial()+"\n";
	}
}