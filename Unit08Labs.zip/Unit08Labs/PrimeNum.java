//(c) A+ Computer Science
//www.apluscompsci.com
//Name

import static java.lang.System.*;
import java.lang.Math;

public class PrimeNum
{
	private int number;

	public PrimeNum()
	{
	}

	public PrimeNum(int num)
	{
	}

	public void setPrime(int num)
	{


	}

	public boolean isPrime()
	{







		return true;
	}

	public String toString()
	{
		String output="";







		return output;
	}
}