//(c) A+ Computer Science
//www.apluscompsci.com
//Name

import static java.lang.System.*;

public class BinToTen
{
	private String binary;

	public BinToTen()
	{
	}

	public BinToTen(String bin)
	{
	}

	public void setBinary(String bin)
	{
	}

	public long getBaseTen( )
	{
		long ten=0;



		return ten;
	}

	public String toString()
	{
		return "";
	}
}