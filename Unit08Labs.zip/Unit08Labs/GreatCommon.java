//(c) A+ Computer Science
//www.apluscompsci.com
//Name

import static java.lang.System.*;

public class GreatCommon
{
	private int one, two;

	public GreatCommon()
	{
	}

	public GreatCommon(int numOne, int numTwo)
	{
	}

	public void setNums(int numOne, int numTwo)
	{
	}

	public long getGCD( )
	{
		long gcd=0;



		return 1;
	}

	public String toString()
	{
		return "";
	}
}