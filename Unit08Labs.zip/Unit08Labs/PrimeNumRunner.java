//(c) A+ Computer Science
//www.apluscompsci.com
//Name

import static java.lang.System.*;
import java.lang.Math;

public class PrimeNumRunner
{
	public static void main ( String[] args )
	{
		PrimeNum test = new PrimeNum(24);
		out.println(test);  //should output "24 is not a prime number)		
	}	
}